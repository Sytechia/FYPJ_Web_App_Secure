CREATE TRIGGER fki_BlogResponses_BlogEntryId_BlogEntries_Id BEFORE INSERT ON BlogResponses FOR EACH ROW BEGIN SELECT RAISE (ROLLBACK, 'Insert on table BlogResponses violates foreign key constraint FK_BlogResponses_BlogEntries') WHERE (SELECT Id FROM BlogEntries WHERE Id = NEW.BlogEntryId) IS NULL; END;

